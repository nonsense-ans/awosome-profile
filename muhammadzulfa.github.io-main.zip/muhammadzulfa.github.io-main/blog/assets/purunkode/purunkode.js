var typed = new Typed('.typed', {
   strings: ['Coba HTML Dasar.', 'Coba CSS Dasar.', 'Coba Javascript Dasar.'],
   typeSpeed: 100,
   backSpeed: 0,
   loop: true
});